package com.example.bookschema;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookSchemaApplicationTests {

	@Test
	void contextLoads() {
	}

}
