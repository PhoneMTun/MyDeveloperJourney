package com.example.bookschema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BookSchemaApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookSchemaApplication.class, args);
	}

}
