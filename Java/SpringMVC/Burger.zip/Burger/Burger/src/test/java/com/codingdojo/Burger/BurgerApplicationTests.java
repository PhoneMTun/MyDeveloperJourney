package com.codingdojo.Burger;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BurgerApplicationTests {

	@Test
	void contextLoads() {
	}

}
