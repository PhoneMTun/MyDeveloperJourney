package com.example.bookschema;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ReBooksSchemaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ReBooksSchemaApplication.class, args);
	}

}
