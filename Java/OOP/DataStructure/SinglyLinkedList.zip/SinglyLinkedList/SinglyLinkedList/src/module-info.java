/**
 * 
 */
/**
 * @author Owner
 *
 */
module SinglyLinkedList {
}