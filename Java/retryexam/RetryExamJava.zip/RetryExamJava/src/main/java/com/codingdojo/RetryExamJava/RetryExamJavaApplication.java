package com.codingdojo.RetryExamJava;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RetryExamJavaApplication {

	public static void main(String[] args) {
		SpringApplication.run(RetryExamJavaApplication.class, args);
	}

}
