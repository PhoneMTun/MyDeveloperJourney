async function next4daysweather(){
//     let weatherData = await genereatedChicago();
//     for(let i = 0; i < weatherData.length; i++) {
//         console.log(weatherData[i].weather);
//     }
// }
// next4daysweather();